function onLoad() {
    // Adding Field Decorators
    g_form.addDecoration("caller_id", "icon-user-profile", "The Requester");
}

# Client Script - Add Field Decoration

A client script that added field decoration.

## Usage

- Create a new OnLoad script
- Copy this script into it
- Change the field name, icon and the message

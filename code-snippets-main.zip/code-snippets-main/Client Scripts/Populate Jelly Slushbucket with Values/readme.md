This code is used to populate the <g:ui_slushbucket up_down="true"/> Jelly tag within a UI Page.

In the UI Page, must ensure that this tag is located in the HTML section.

Then in the client script, include the code provided in the example.

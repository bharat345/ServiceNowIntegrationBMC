var currentDateObj = new Date();
var currentDateUsr = formatDate(currentDateObj, g_user_date_format);

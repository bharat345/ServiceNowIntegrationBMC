## This is OnChange client Script
# whenever the 'State' on incident table will change to 'on Hold' the 'work notes' will become mandatory
While using this script the table should be selected as 'incident' and type should be 'onChange' and field should be selected as 'State'. then write the script.

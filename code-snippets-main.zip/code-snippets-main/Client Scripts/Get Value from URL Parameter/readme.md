Script that can be used in Client scripts to get URL parameter value.

** Isolate script should be **false**

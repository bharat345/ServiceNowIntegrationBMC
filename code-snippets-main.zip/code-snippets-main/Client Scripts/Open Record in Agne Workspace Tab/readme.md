This code helps to open a record in readonly mode irrespective of ACLS, UI Policies via client script in a Agent workspace tab.

Here we are opening a story that is stored in the parent field on the incident record in the agent workspace.

Use this script to show a field after `n` checkboxes are checked and not before.

**Tested in Global scope
**You can't make mandatory fields as readonly
**Best Practice is to use UI Policies
**Sometimes you have a lot of check marks and that logic gets narly

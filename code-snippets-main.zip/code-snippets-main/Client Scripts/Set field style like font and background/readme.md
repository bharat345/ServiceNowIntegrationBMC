# Client Script - Change field style

A client script that changes field font, and background based on some condition
And example would be if the currently raised incident is by a VIP user and hightlight the caller...

## Usage

- Create a new OnLoad script
- Copy this script into it
- Set the condition and the field that requires to be changed

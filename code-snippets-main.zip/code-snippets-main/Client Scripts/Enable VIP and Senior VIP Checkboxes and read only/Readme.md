This script is to enable The VIP and Senior VIP check boxes on the user form to be visible but read-only for any user who is not a system administrator.  ths script helps to better manage the VIP users and better administration of the Platform. 
You need to run this client script on the sys_user table and UI Type as Desktop <as per your requirement> and Type as "On load" and make this as Global.

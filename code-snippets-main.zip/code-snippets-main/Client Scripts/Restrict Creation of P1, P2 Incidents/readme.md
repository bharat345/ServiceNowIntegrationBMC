The code snippet can be used to restrict the creation of priority P1, P2 incidents except for the admins and a particular group members.

To achieve this requirement, I have created a onChange client script for the field name "Priority" and also created a script include to get the necessary data from the server side.

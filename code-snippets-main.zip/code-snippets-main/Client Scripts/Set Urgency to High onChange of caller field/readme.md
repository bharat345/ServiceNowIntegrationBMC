This is a client script that change urgency to high automatically when changing caller field with the caller name whose vip is true

The Delete RITM attachment business rule will automatically deletes the attachment on RITM, when the attachment is deleted on SCTASK.

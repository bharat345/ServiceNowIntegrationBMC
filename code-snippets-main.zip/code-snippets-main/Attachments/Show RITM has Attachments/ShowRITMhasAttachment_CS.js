function onLoad() {
	if (g_scratchpad.hasAttachments == true) {
		g_form.showFieldMsg('request_item', "Contains attachment(s)",'info');
	}
}

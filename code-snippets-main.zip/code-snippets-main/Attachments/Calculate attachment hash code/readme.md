This is example of recalculate the hash code using the glide digest getSHA256HexFromInputStream method.

GlideDigest() -
    This class provides methods for creating a message digest from strings or input streams using MD5, SHA1, or SHA256 hash algorithms.

Docs link: https://developer.servicenow.com/dev.do#!/reference/api/tokyo/server/no-namespace/c_GlideDigestScopedAPI#r_SGDigest-GlideDigest

getSHA256HexFromInputStream - function takes GlideScriptableInputStream input stream as parameter.
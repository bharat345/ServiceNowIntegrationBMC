## Copy URL to ServiceNow Journal
A bookmarklet that can be used on any website to copy the website's title and URL to the clipboard as a [code]...[/code] snippet that can be pasted to a Journal field to create a "fancy" clickable link in Comments or Work notes.

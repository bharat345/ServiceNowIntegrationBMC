# Convert the currency from one country denomination to other
This is for the currency conversion purpose and the js file has the code snippet 

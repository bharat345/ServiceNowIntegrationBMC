**Generate Random Incident Records**
This script can be used to generate random Incident records for testing purposes.

**Usage**
Can be used to run on demand in Scheduled Script Execution.

**Scenario**
Used to generate records in PDI for testing reports and graphs.

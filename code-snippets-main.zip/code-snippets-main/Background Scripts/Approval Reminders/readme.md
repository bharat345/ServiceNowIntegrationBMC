Use Case: Approval are pending due approver unavailability

Solution : Assign delgates to the approver and send reminder email notification using the Approval reminder code.It will send email to delgates and they will get notified with the approval request to approve/reject per limited period.

Steps: Register an event and create a notification to send  email to manager when the event fired/triggered.

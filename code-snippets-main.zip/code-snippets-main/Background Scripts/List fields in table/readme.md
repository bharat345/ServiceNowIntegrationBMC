# Get Fields in Table

Quick script to print out the fields on one or multiple tables. Especialy helpful for CMBD tables when a stakeholder inevitably asks "Can you send me a list of all the tables and fields?

## Use

Simply add the table names from you wish to display the fields in the **table** array.

## Current Configuration

A demo list of CMDB tables is included. The script will list the fields numbered, in alphabetical order, and includes actual field name and label name.

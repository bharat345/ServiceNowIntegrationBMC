gs.info(
  SNC.UsageAnalyticsScriptUtils.getCount(
    'Primary DB size (MB)',
    'Primary DB size of this instance (in MB)'
  )
); //Run this code in the Background Scripts module to get the size of the DB

Use the code to change approver for any record from background script
Replace <Approval_record_sys_id> with sys_id of record for which approval is triggered
Replace <User_Display_Name> with name of user who needs to be set as approver

This business rule script copies the additional comments from SCTASK to all associated RITM when additional comments are changed on the SCTASK.

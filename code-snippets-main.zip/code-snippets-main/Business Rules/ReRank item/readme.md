Business rule for on after to re-rank a field spaced by 10 in each entry
it updates itself and any larger numbered rank item to keep them all in sync

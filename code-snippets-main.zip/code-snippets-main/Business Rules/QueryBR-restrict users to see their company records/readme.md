This script is used to restrict logged in users to see only their company records. This is a generic script and can be used in any table where there is a Company field present
which is associated to the User table.
Query BR contains below specifications:
1. Advanced = true
2. When = Before
3. Query = true

Example code to make attachement mandatory. 

It can be reusabel on any table uisng before Business rule,on addition we can add addAggregate to  make two attachements mandatory.

* [GlideAggregate](https://developer.servicenow.com/dev.do#!/reference/api/tokyo/server/no-namespace/c_GlideAggregateScopedAPI) 
* [GLIDEAGGREGATE Use case](https://developer.servicenow.com/blog.do?p=/post/glideaggregate/)

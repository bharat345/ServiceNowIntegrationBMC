Sample code snippet to copy the latest task worknotes comments to additional comments of related RITM record.
So the requester aware of recent updates of tasks.

Type: Business Rule When: OnBefore and On Insert Operation  Table:Incident
This BR runs on Insert Operation , IT compares the filename from Sysattachment table and if same attachment with Same file exists on the Incident this BR runs and Abort the Attaching Attachments

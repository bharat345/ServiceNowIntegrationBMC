If user update work notes of problem task then it should update the same worknotes in parent problem record as well with highlighting problem task number.
this business rule run after updation when worknote changes.

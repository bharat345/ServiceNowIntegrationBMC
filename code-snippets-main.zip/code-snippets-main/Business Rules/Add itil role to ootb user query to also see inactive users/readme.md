A common request is to also allow itil users to also be able to see inactive user records.
There are two pieces of code in the code.js file:
1) A conditional piece of code that should be added to the "Condition" field within the business rule
2) A single line that should be added to the "Script" field within the business rule

Name: Round [Field] to nearest [Rounding Amount]
UI Type: All
Type: onChange

Variable name: [VAR NAME]

Script: see `catalog_client_script.js` for code.
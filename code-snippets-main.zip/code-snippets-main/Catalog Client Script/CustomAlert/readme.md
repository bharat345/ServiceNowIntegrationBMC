These scripts helps you to create custom popup easily. follow the below steps to implement it on your instance.

Steps
1. Create UI page with name "custom_alert_box"
2. Copy HTML section from customn_alert_box.js to HTML field of UI Page
3. Copy Client Script section from customn_alert_box.js to Client Script field of UI Page
4. UI Page is ready to be used.
5. Refer the "custom_alert.js" to create client script or catalog client script to alert HTML messages or links in custom alert format.
6. Refer the screenshots folder for quick look.

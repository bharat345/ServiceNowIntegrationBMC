# Remove reference icon from portal using Catalog Client script of a Catalog Item

This catalog client script is design to remove the reference icon from the Portal for any reference field record.
This needs to be configured for each Catalog Item where the reference field is being used.

* [Click here for script](remove-reference-icon-from-portal-onLoad.js)
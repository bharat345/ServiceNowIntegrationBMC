# Catalog Task state should not be closed from list edit
The onCellEdit Client Script type is used for lists rather than forms and here 
it is being used so that the task should not be closed from the list edit without
opening the form and filling other mandatory details like worknotes etc.

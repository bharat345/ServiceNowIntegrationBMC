## Currency Validation 

Use this catalog client script to validate the value of a variable used to get currency. As of now 3 things are being checked in the script but you can make changes as per requirement.

1) Characters after the $ sign should be numerics.
2) Entered value should have a decimal point.
3) There must be 2 digits only after the decimal.

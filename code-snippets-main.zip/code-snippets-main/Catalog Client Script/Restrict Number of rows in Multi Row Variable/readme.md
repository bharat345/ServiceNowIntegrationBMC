## restrict_multi_row.js
Use this to restrict multi row variable set rows to 1. this value can be changed to any number of rows as requirement.

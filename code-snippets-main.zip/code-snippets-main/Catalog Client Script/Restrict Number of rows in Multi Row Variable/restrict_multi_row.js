function onLoad() {
	var field = g_form.getField("mrvs_variable_set_name");
	if (field != null) {
		field.max_rows_size = 1;
	}
}

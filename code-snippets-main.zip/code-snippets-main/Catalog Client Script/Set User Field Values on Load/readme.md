On Load Catalog client script is created to auto set the field values and make that field read only
 - Navigate to your instance -> App Navigator > Open Catalog CLient Script [catalog_script_client]
 - Set following field Values
        - Name: xyz
        - Applies to: A Catalog item
        - Type: onLoad
        - Catalog item: Select your Catalog item
        - UI Type: All
        - Isolated script: Checked
  -  Create the script as per script.js file.
